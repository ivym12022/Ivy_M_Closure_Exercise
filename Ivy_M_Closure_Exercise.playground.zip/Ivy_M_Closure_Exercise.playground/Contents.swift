import UIKit

var multiply = {(Num1: Int, Num2: Int) -> Int in
    return Num1 * Num2
}
let product = multiply(50,50)
print(product)
